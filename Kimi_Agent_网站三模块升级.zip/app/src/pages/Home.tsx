import { useNavigate } from 'react-router';
import { Brain, Newspaper, Database, FileText, ArrowRight } from 'lucide-react';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 overflow-hidden">
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23722F37' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-burgundy/10 text-burgundy text-sm font-medium mb-6">
              <Brain className="w-4 h-4" />
              <span>神经科学 × 哲学</span>
            </div>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-burgundy mb-6 leading-tight">
              探索认知边界
            </h1>
            <p className="text-lg text-slate-blue/80 mb-6 italic">
              Exploring the Boundaries of Cognition
            </p>
            <p className="text-slate-blue/70 text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
              在认知革命的前夜，我们追踪最前沿的脑科学，追问最深层的认知问题
              ——在这个奇点时刻，理解人之所以为人的边界。
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-slate-blue/70">
              <span className="inline-flex items-center px-4 py-2 rounded-full border border-burgundy/20 bg-white">
                跨学科深度
              </span>
              <span className="inline-flex items-center px-4 py-2 rounded-full border border-burgundy/20 bg-white">
                8年药企经验
              </span>
              <span className="inline-flex items-center px-4 py-2 rounded-full border border-burgundy/20 bg-white">
                新中双视角
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Module Cards */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl font-bold text-burgundy mb-4">
              三大核心板块
            </h2>
            <p className="text-slate-blue/70 max-w-2xl mx-auto">
              从日常文章撰写到企业数据库，再到行业深度报告，全方位覆盖神经科技领域
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
            {/* Module 1: Articles */}
            <button
              onClick={() => navigate('/articles')}
              className="group relative text-left bg-white rounded-2xl border border-gray-200 p-8 transition-all duration-300 hover:shadow-card-hover hover:border-burgundy/20 hover:-translate-y-1"
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-burgundy/10 mb-6 transition-transform duration-300 group-hover:scale-110">
                <Newspaper className="w-7 h-7 text-burgundy" />
              </div>
              <h3 className="font-serif text-xl font-bold text-burgundy mb-3">
                文章撰写
              </h3>
              <p className="text-slate-blue/70 text-sm leading-relaxed mb-6">
                神经科学与哲学交叉视角的深度文章，追踪脑科学前沿动态，解读认知科学最新研究。
              </p>
              <div className="flex items-center gap-2 text-burgundy text-sm font-medium">
                <span>浏览文章</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
              <div className="absolute top-4 right-4 w-2 h-2 bg-gold rounded-full" />
            </button>

            {/* Module 2: Database */}
            <button
              onClick={() => navigate('/database')}
              className="group relative text-left bg-white rounded-2xl border border-gray-200 p-8 transition-all duration-300 hover:shadow-card-hover hover:border-burgundy/20 hover:-translate-y-1"
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-burgundy/10 mb-6 transition-transform duration-300 group-hover:scale-110">
                <Database className="w-7 h-7 text-burgundy" />
              </div>
              <h3 className="font-serif text-xl font-bold text-burgundy mb-3">
                企业数据库
              </h3>
              <p className="text-slate-blue/70 text-sm leading-relaxed mb-6">
                覆盖105+家中国神经科技企业，涵盖脑机接口、神经调控、上游供应链及下游应用全链条。
              </p>
              <div className="flex items-center gap-2 text-burgundy text-sm font-medium">
                <span>查看数据库</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
              <div className="absolute top-4 right-4 px-2 py-0.5 text-[10px] bg-gold/20 text-gold-dark rounded-full font-semibold">
                NEW
              </div>
            </button>

            {/* Module 3: Reports */}
            <button
              onClick={() => navigate('/reports')}
              className="group relative text-left bg-white rounded-2xl border border-gray-200 p-8 transition-all duration-300 hover:shadow-card-hover hover:border-burgundy/20 hover:-translate-y-1"
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-burgundy/10 mb-6 transition-transform duration-300 group-hover:scale-110">
                <FileText className="w-7 h-7 text-burgundy" />
              </div>
              <h3 className="font-serif text-xl font-bold text-burgundy mb-3">
                BCI 行业报告
              </h3>
              <p className="text-slate-blue/70 text-sm leading-relaxed mb-6">
                脑机接口行业深度研究报告专题，涵盖市场分析、技术趋势、政策解读等多维度内容。
              </p>
              <div className="flex items-center gap-2 text-burgundy text-sm font-medium">
                <span>浏览报告</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
              <div className="absolute top-4 right-4 px-2 py-0.5 text-[10px] bg-gold/20 text-gold-dark rounded-full font-semibold">
                NEW
              </div>
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <Brain className="w-6 h-6 text-burgundy" />
              <span className="font-serif text-lg font-bold text-burgundy">PhiNeuro</span>
              <span className="text-xs text-slate-blue/50 ml-2">Phi的神经观</span>
            </div>
            <p className="text-sm text-slate-blue/60">
              在认知革命的前夜，追踪最前沿的脑科学，追问最深层的认知问题
            </p>
            <div className="flex items-center gap-6 text-sm text-slate-blue/60">
              <a href="#" className="hover:text-burgundy transition-colors">小红书</a>
              <a href="#" className="hover:text-burgundy transition-colors">公众号</a>
              <a href="#" className="hover:text-burgundy transition-colors">X</a>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-gray-100 text-center text-xs text-slate-blue/40">
            <p>&copy; 2024-2025 PhiNeuro. 探索认知边界. 数据仅供参考，不构成投资建议.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
